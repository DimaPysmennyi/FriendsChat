import customtkinter
import modules.screen_app as m_app
import modules.create_button as m_button


m_app.main_app.mainloop()